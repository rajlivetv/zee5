<p align="center"><img src="https://www.pngkit.com/png/full/353-3536377_with-all-this-content-available-in-one-place.png" width="100" height="100"></p>

<h1 align="center"> ✯ ZEE5 LIVETV ✯ </h1>

<p align="center"><b>It can scrape ZEE5 Live Streaming URL's Using The Channel ID and Direct Play Anywhere</b></p><br>

<h2>🍁 How To Use : </h2>

<h4>
• Go to <a href="https://www.zee5.com/channels">ZEE5 Live TV</a> Page <br><br>
• Click on the channel which links you want to extract <br><br>
• Copy the channel's ID from the URL box <br><br>
• e.g --> Use This Link : https://www.zee5.com/channels/details/zee-cinema-hd/0-9-zeecinemahd <br><br>
• Copy the ID e.g. <code>0-9-zeecinemahd</code> at end of URL <br><br>
  • Copy and paste the ID after this URL without <code>0-9-</code> --> <code> https://localhost/?c=CHANNEL_ID</code> <br><br>
• The final URL is --> https://localhost/?c=0-9-zeecinemahd <br><br>
• Run said final URL in your browser, and then you'll get the stream's URL <br>
</h4>
<br><br>

## 🍃 Easy Way

<h4>
  
• Insert ID after <code>0-9-</code> : https://localhost/?c=0-9-zeecinemahd |  ( A specific player )<br><br>
• Insert ID after <code>0-9-</code> : https://localhost/?c=CHANNEL_ID  |  ( Other players )
  
  </h4><br>

## CHANNEL_ID 

<br>

## == ID LIST ==

<br>

### Entertainment :

• 0-9-zeetv <br>
• 0-9-zeetvhd <br>
• 0-9-zeetalkies <br>
• 0-9-zeeyuva <br>
• 0-9-tvhd_0 <br>
• 0-9-bigmagic_1786965389 <br>
• 0-9-zeeanmol <br>
• 0-9-zeemarathi <br>
• 0-9-zeecafehd


### Movies :

• 0-9-zeecinemahd <br>
• 0-9-channel_2105335046 <br>
• 0-9-tvpictureshd <br>
• 0-9-zeeaction <br>
• 0-9-zeeclassic <br>
• 0-9-zeecinema <br>
• 0-9-zeeanmolcinema <br>
• 0-9-176 <br>
• 0-9-209  <br><br>
  0-9-zeecafehd
	
  0-9-channel_2105335046

### Music :

• 0-9-353 <br>
• 0-9-zing <br>
• 0-9-133 <br>
• 0-9-134  <br><br>


### News

• 0-9-273 <br>
• 0-9-wion <br>
• 0-9-zeenews <br>

  
## For Examples :-

1. https://localhost/?c=0-9-zeecinemahd <br><br>
2. https://localhost/?c=0-9-tvhd_0 <br><br>
3. https://localhost/?c=0-9-353 <br><br>
4. https://localhost/?c=0-9-wion <br><br>
5. https://localhost/?c=0-9-zeetvhd <br><br>
and many more .......
 
  

<h3>• Check List Of Channel Id's <a href="Channel_IDs.md">Here</a></h3>
<br>

<h2> Where To Host : </h2>

<h5 align="center"> Copy The index.php code and Host on Heroku <br> or Your Hosting Otherwise Use https://sneh-z5api.herokuapp.com/
  
  
---
<h5 align='center'>© 2021 Techie Sneh</h5>
