```py
             Copyright 2021 Techie Sneh
           
  [+] - Star 🌟 Before Copying this 😢  
  [+] - Follow me and get some new APIs and Repository 😅
  [+] - EveryOne can Use this Freely Here !!
  [+] - DO NOT sell anything or don't buy anyone like this its free 
  [+] - DO NOT remove Credit After Copying 😈
  
  ```
