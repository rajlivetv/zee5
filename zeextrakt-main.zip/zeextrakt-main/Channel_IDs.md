## Channel IDs - Z5

### Channel list will be updated to reflect all streams.

### Need Geo addition :

- 0-9-zeenung (Add "&country=*insert country other than US, UK and IN*")

### Entertainment :

- 0-9-zeetv
- 0-9-zeetvhd
- 0-9-zeetalkies
- 0-9-zeeyuva
- 0-9-tvhd_0
- 0-9-bigmagic_1786965389
- 0-9-zeeanmol
- 0-9-zeemarathi
- 0-9-zeecafehd

### Movies :

- 0-9-zeecinemahd
- 0-9-channel_2105335046
- 0-9-tvpictureshd
- 0-9-zeeaction
- 0-9-zeeclassic
- 0-9-zeecinema
- 0-9-zeeanmolcinema
- 0-9-176
- 0-9-209
- 0-9-zeecafehd
- 0-9-channel_2105335046

### Music :

- 0-9-353
- 0-9-zing
- 0-9-133
- 0-9-134

### News : 

- 0-9-273
- 0-9-wion
